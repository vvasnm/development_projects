package com.password.manager.util;

import org.eclipse.swt.widgets.Shell;
import com.password.manager.ui.DetailsPage;
//import com.password.manager.ui.LoginPage;

public class MainClass {
	public static void main(String[] args) {		
		Shell shell = new Shell();	    
		DetailsPage login = new DetailsPage(shell, 0);		
		login.open();
	}
}

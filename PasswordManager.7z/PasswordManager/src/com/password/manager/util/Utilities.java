package com.password.manager.util;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import com.password.manager.bean.PMData;
import com.password.manager.dao.DBConnection;


public class Utilities {
	
	public Utilities(){		
		super();		
	}
    Shell shell = new Shell();
   // static Logger log = Logger.getLogger(Utilities.class.getName());	
	public void createUserProfile(PMData pmdata,Shell shl){
		int rowCnt = 0;						
		createUserTable();				
		rowCnt = rowCount(Constants.DB_USER_TABLE);		
		if (rowCnt == 0){
			// in this way we are restricting the application is only for single user.
			insertUserInfo(pmdata);
		}
		else{
			writeLogFile( "\nI am inside the else of createUserProfile... ");
			MessageBox mBox = new MessageBox(shl,0);
			mBox.setMessage(Constants.UNIQUE_USER_ERROR);			
			mBox.open();
		}					
	}
	 
	
	//This Function Writes log File to TEMP folder...
	public void writeLogFile (String logInfo){
		String logFile = System.getenv("TEMP").concat(Constants.SEPERATOR).concat(Constants.LOGFILE);
		Logger logger = Logger.getLogger(Constants.LOGFILE); 
		FileHandler fh = null;
		try {
			fh = new FileHandler(logFile);
			logger.addHandler(fh);
		    SimpleFormatter formatter = new SimpleFormatter();  
		    fh.setFormatter(formatter);		    
		    logger.info(logInfo); 		    
		} 
		catch (SecurityException | IOException e) {			
			e.printStackTrace();
		}			    
	}
// Create User Table creates the table of not exist.
	public void createUserTable() {
		Connection con = null; 
		try {
			 con = DBConnection.getDBConnection();
			 con.setAutoCommit(false);
			 Statement stmt = null;
			 String sqlQuery = null;
			 stmt = con.createStatement();	
			 writeLogFile( "\nI am inside the createUserTable...function");
			 sqlQuery = " CREATE TABLE IF NOT EXISTS PUSERPROFILE " +
	                    "(ID  INT PRIMARY KEY     NOT NULL, " +
					    " NAME           TEXT     NOT NULL, " + 
	                    " USERNAME       TEXT     NOT NULL, " + 	                   
	                    " PASSWORD       CHAR(50))         " ; 			 
			 stmt.executeUpdate(sqlQuery);
			 con.commit();
			 stmt.close();			 
		 } 		
		catch( SQLException e ) {
	    	if( con != null ) {
	    		try { con.rollback(); }        // rollback on error 
	    		catch( SQLException ee ) { }
	    	}
	    	e.printStackTrace();
	    }finally {
	    	try { con.close(); }
	    	catch( SQLException e ) { e.printStackTrace(); }
	    }
	}			
	public  int rowCount(String tableName){
		writeLogFile("Inside rowCount function...");
		int rowCount = 0;
		Connection con = null; 						
		try {
			 con = DBConnection.getDBConnection();
			 con.setAutoCommit(false);
			 Statement stmt = null;
			 String sqlQuery = null;
			 stmt = con.createStatement();							
			 sqlQuery = "SELECT COUNT (*) FROM " + tableName.concat(";"); 
			 ResultSet rs =  stmt.executeQuery(sqlQuery);		
			 while (rs.next()) {
				 rowCount = rs.getInt(1);
			 }			 			
			 stmt.close();			
		 } catch( SQLException e ) {
	    	if( con != null ) {
	    		try { con.rollback(); }        // rollback on error 
	    		catch( SQLException ee ) { }
	    	}
	    	e.printStackTrace();
	    }finally {
	    	try { con.close(); }
	    	catch( SQLException e ) { e.printStackTrace(); }
	    }
		writeLogFile("Total Rows in DB table : " + rowCount);
		//log.info("\nINFO: Total Rows in DB table : " + rowCount);
		
		return rowCount;
	}
	
	// This function is used at the time of new user creation.
	public void insertUserInfo(PMData pmdata){
		writeLogFile("Inside insertUserInfo function...");
		try {  
			 Connection con = DBConnection.getDBConnection(); 
			 con.setAutoCommit(false);
		     String OpenBracket   = "(";  
		     String ClosedBracket = ")"; 
		     String SemoColon     = ";";
		     String Quote1        = "'";
		     
		     int sNo = Integer.parseInt(pmdata.getNewUserSno());
		                            //"(1,'DBSBANK','svad','12345');";   
		     String valueString1  = OpenBracket + sNo +",".concat(Quote1).concat(pmdata.getNewUser()).concat(Quote1).concat(",").concat(Quote1).concat(pmdata.getNewUserID()).concat(Quote1).concat(",").concat(Quote1).concat(pmdata.getNewUserPassword()).concat(Quote1).concat(ClosedBracket).concat(SemoColon);
		     
			 Statement stmt = null;
			 String sqlQuery = null;
			 stmt = con.createStatement();
			 sqlQuery = "INSERT INTO PUSERPROFILE (ID,NAME,USERNAME,PASSWORD)"
			 		    + " VALUES"  
					    +  valueString1 ;			 
			 stmt.executeUpdate(sqlQuery);
			 con.commit();
			 stmt.close();
		 } 
		 catch (SQLException e) {			 
			 writeLogFile( e.getClass().getName() + ": " + e.getMessage());			 			 			 			 		
		     System.exit(0);
		 }
		//log.info("\nINFO: User Profile Created Successfully...");
		writeLogFile("User Profile Created Successfully...");
		
	}			
	// This function is used to validate username/password at the time of login.
	
	private PMData queryCretentials(PMData pmdata){
		writeLogFile("Inside queryCretentials function...");
		Connection con = null;			
		con  = DBConnection.getDBConnection();			
		try {						
			Statement stmt = con.createStatement();			
			con.setAutoCommit(false);													
			ResultSet rs = stmt.executeQuery( "SELECT * FROM PUSERPROFILE;" );			
			while ( rs.next()){	
				//writeLogFile("Inside while...");
				 int id = rs.getInt("id"); 							 
				 String  userName  = rs.getString("username");
		         String  password  = rs.getString("password");
		         String sNo = Integer.toString(id);	
		         //Setting the values to PMData
		         pmdata.setsNoDB(sNo);		       
		         pmdata.setUserNameDB(userName);
		         pmdata.setPassWordDB(password);	
		         writeLogFile("Got the Credentials and passed to PMData...");
		     }
			rs.close();
		    stmt.close();						
		    con.close();									
	  } catch (SQLException e) {				  
		  System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	  }	      			
		return pmdata;
	}
	
	public boolean isUserValid (PMData pmdata){		
		boolean isValid = false;	    
		PMData data1 = queryCretentials(pmdata);					
		if ((data1.getUserNameDB().equals(pmdata.getUsername())) 
			&& (data1.getPassWordDB().equals(pmdata.getPassword()))){
		    isValid = true;	
		    writeLogFile("User Exist, Providing access to User:" +  pmdata.getUsername());
		}				
		return isValid;
	}
	
	public boolean isDBExists(){
		boolean isExist = false;
		File file = new File (Constants.DB_FILE);
		 if(file.exists()) {
	         isExist = true;
	     }	 
		 return isExist;
	}
	
	
	public boolean istableExists(String tableName){
		boolean isExists = false;		
		ResultSet rs = null;
		String sqlQuery , table = null;
		Statement stmt = null;
		Connection con = DBConnection.getDBConnection();
		try {
			con.setAutoCommit(false);
			stmt = con.createStatement();							
			sqlQuery = "SELECT name FROM sqlite_master WHERE type='table' AND name='" + tableName + "'"+";";
			rs = stmt.executeQuery(sqlQuery);			     				    			
			while (rs.next()){	
				table  = rs.getString("name");	    
				if (table.equals(tableName)){
					isExists = true;										
				}
			}			
		   stmt.close();						
		   con.close();			  		   																			
		} catch (SQLException e) {			
			  writeLogFile( e.getClass().getName() + ": " + e.getMessage());			  
		      System.exit(0);
		}	
		return isExists;		
	}
	
	public void clearFiles(String folderLocation){
		File folder = new File(folderLocation);
		File folderContent[] = folder.listFiles();		
		for (int i = 0; i < folderContent.length; i++) {
		    File pes = folderContent[i];
		    if (!pes.getName().endsWith(".log"))   {		    	
		    	//System.out.println("folderContent[i] - .dll:" + folderContent[i] );
		    	folderContent[i].delete();
		    }
		    
		}
	}
}
	
	

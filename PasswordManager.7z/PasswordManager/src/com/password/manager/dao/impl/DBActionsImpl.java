package com.password.manager.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.password.manager.bean.QueryData;
import com.password.manager.dao.DBActions;
import com.password.manager.dao.DBConnection;
//import com.password.manager.util.Constants;
import com.password.manager.util.Utilities;

public class DBActionsImpl implements DBActions {

	Utilities util = new Utilities();
	static Logger log = Logger.getLogger(DBActionsImpl.class.getName());
	@Override
	public void createPMDataTable() {
		Connection con = null; 
		try {
			 con = DBConnection.getDBConnection();
			 con.setAutoCommit(false);
			 Statement stmt = null;
			 String sqlQuery = null;
			 stmt = con.createStatement();	
			 util.writeLogFile( "\nIn createPMDataTable...function");		
			 sqlQuery = "CREATE TABLE  PDETAILS (HEAD TEXT   PRIMARY KEY  NOT NULL,LABEL TEXT NOT NULL,USERNAME  TEXT NOT NULL,PASSWORD  CHAR(50));";	                    			 
			 stmt.executeUpdate(sqlQuery);
			 con.commit();
			 stmt.close();
			 util.writeLogFile( "\nTable Created Successfully!!");
		 } 		
		catch( SQLException e ) {
	    	if( con != null ) {
	    		try { con.rollback(); }        // rollback on error 
	    		catch( SQLException ee ) { }
	    	}
	    	e.printStackTrace();
	    }finally {
	    	try { con.close(); }
	    	catch( SQLException e ) { e.printStackTrace(); }
	    }		
	}			
	@Override
	public void insertPMDetails(QueryData qData) {
		util.writeLogFile( "\nI am inside the insertPMDetails...function");		
		try  {  
			 Connection con = DBConnection.getDBConnection(); 
			 con.setAutoCommit(false);
		    // int rowCnt = 0;
			 String OpenBracket   = "(";  
		     String ClosedBracket = ")"; 
		     String SemoColon     = ";";
		     String Quote         = "'";		     
		    // rowCnt = util.rowCount(Constants.DB_PM_TABLE)+1;		     		                             
		     String valueString1  = OpenBracket.concat(Quote).concat(qData.getPmHead()).concat(Quote).concat(",").concat(Quote).concat(qData.getLabel()).concat(Quote).concat(",").concat(Quote).concat(qData.getPmUsername()).concat(Quote).concat(",").concat(Quote).concat(qData.getPmPassword()).concat(Quote).concat(ClosedBracket).concat(SemoColon);		    
			 Statement stmt = null;
			 String sqlQuery = null;
			 stmt = con.createStatement();
			 sqlQuery = "INSERT INTO PDETAILS (HEAD,LABEL,USERNAME,PASSWORD)"
			 		    + " VALUES"  
					    +  valueString1 ;			 
			 stmt.executeUpdate(sqlQuery);
			 con.commit();
			 stmt.close();
			 util.writeLogFile( "\nValues Inserted into DB Successfully!!");
		 } 
		 catch (SQLException e){			 
			 util.writeLogFile( e.getClass().getName() + ": " + e.getMessage());			 			 			 			 		
		     System.exit(0);
		 }			
	}			
	@Override
	public void updatePMDetails(String tablename, String[] Columns) {
		// TODO Auto-generated method stub	
	}
	@Override
	public void deletePMDetails(QueryData qData) {
		Connection con = null;
		util.writeLogFile( "Inside deletePMDetails function...");		
	    String existingHead = null;
		con  = DBConnection.getDBConnection();
		existingHead = qData.getPmExistingHead();
		try {						
			Statement stmt = con.createStatement();			
			con.setAutoCommit(false);	
			String sqlQuery = "DELETE FROM PDETAILS WHERE HEAD="+"'"+existingHead+"'" + ";";			
			stmt.executeUpdate(sqlQuery);						
		    stmt.close();	
		    con.commit();
		    con.close();	
		    util.writeLogFile( "Selected Head deleted Successfully...");
	  } 
	  catch (SQLException e) {		
		  System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	  }	      										
	}    
	@Override
	public QueryData selectPMDetails(QueryData qData) {
		Connection con = null;
		//util.writeLogFile( "Inside selectPMDetails function...");
	    String whereClause = null;  
		con  = DBConnection.getDBConnection();			
		try {						
			Statement stmt = con.createStatement();			
			con.setAutoCommit(false);			
			whereClause = qData.getWhereClauseField();			
			String sqlQuery = "SELECT * FROM PDETAILS WHERE HEAD = " + "'" + whereClause + "'" +  ";";			
			ResultSet rs = stmt.executeQuery( sqlQuery );
			int i=0;
			while (rs.next()){					
				 String  head      = rs.getString("HEAD"); 							 
				 String  userName  = rs.getString("USERNAME");
		         String  password  = rs.getString("PASSWORD");
		         i++;
		         qData.setAccountDB(head);	
		         qData.setUserNameDB(userName);
		         qData.setPassWordDB(password);		                 
		     }
			qData.setRowCnt(i);
			rs.close();
		    stmt.close();						
		    con.close();									
	  } 
	  catch (SQLException e) {				  
		  System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);}	      				
		return qData;		
	}		
	public QueryData getExistingHeads(){		
		util.writeLogFile( "Inside getExistingHeads function..");
		Connection con = null;	
		ResultSet rs = null;
		//int rowCnt,inx = 0;
		int inx = 0;
		//rowCnt = util.rowCount(Constants.DB_PM_TABLE);
		String [] head= new String [20];		
		con  = DBConnection.getDBConnection();		
		QueryData qData = new QueryData();
		try {											
			con.setAutoCommit(false);
			Statement stmt = con.createStatement();	
			String sqlQuery =  "SELECT HEAD FROM PDETAILS;";
			rs = stmt.executeQuery(sqlQuery);				
			while ( rs.next() ){										
				head[inx] = rs.getString("HEAD"); 													
				inx++;				
			//	if (inx==rowCnt) break;				
				String [] headNotNull = removeNullValue(head);				
				qData.setHead(headNotNull);								
		    }					        												 								
			rs.close();
		    stmt.close();						
		    con.close();								   		    		    
	  } 
	  catch (SQLException e)  {				  
		  System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	  }	      				
		return qData;
	}
	
	private String [] removeNullValue (String [] head){
	   
		List<String> list = new ArrayList<String>();
		for(String s : head) {
		       if(s != null && s.length() > 0) {
		          list.add(s);
		       }
		    }   
		head = list.toArray(new String[list.size()]);

	    return head;
	}
}

package com.password.manager.bean;

public class QueryData {	
	private String pmHead = null;
	private int pmSno =0;
	private String pmExistingHead = null;
	private String pmUsername = null;
	private String pmPassword = null;
	private String label = null;
	private String [] head = null;
	private String pmReNewPassword = null;
	private String whereClauseField = null;
	private String userNameDB = null;
	private String passWordDB = null;
	private String accountDB = null;
	private int rowCnt =0;
	
	public String getPmReNewPassword() {
		return pmReNewPassword;
	}
	public void setPmReNewPassword(String pmReNewPassword) {
		this.pmReNewPassword = pmReNewPassword;
	}	
	public String[] getHead() {
		return head;
	}
	public void setHead(String[] head) {
		this.head = head;
	}    
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}	
	public String getPmHead() {
		return pmHead;
	}
	public void setPmHead(String pmHead) {
		this.pmHead = pmHead;
	}
	public int getPmSno() {
		return pmSno;
	}
	public void setPmSno(int pmSno) {
		this.pmSno = pmSno;
	}
	public String getPmExistingHead() {
		return pmExistingHead;
	}
	public void setPmExistingHead(String pmExistingHead) {
		this.pmExistingHead = pmExistingHead;
	}
	public String getPmUsername() {
		return pmUsername;
	}
	public void setPmUsername(String pmUsername) {
		this.pmUsername = pmUsername;
	}
	public String getPmPassword() {
		return pmPassword;
	}
	public void setPmPassword(String pmPassword) {
		this.pmPassword = pmPassword;
	}
	public String getWhereClauseField() {
		return whereClauseField;
	}
	public void setWhereClauseField(String whereClauseField) {
		this.whereClauseField = whereClauseField;
	}
	public String getUserNameDB() {
		return userNameDB;
	}
	public void setUserNameDB(String userNameDB) {
		this.userNameDB = userNameDB;
	}
	public String getPassWordDB() {
		return passWordDB;
	}
	public void setPassWordDB(String passWordDB) {
		this.passWordDB = passWordDB;
	}
	public String getAccountDB() {
		return accountDB;
	}
	public void setAccountDB(String accountDB) {
		this.accountDB = accountDB;
	}
	public int getRowCnt() {
		return rowCnt;
	}
	public void setRowCnt(int rowCnt) {
		this.rowCnt = rowCnt;
	}
}

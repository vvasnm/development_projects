package com.password.manager.dao;

import com.password.manager.bean.QueryData;

public interface DBActions {
	
	public QueryData selectPMDetails(QueryData qData);
	public void insertPMDetails(QueryData qData);
	public void updatePMDetails(String tablename, String [] Columns);
	public void deletePMDetails(QueryData qData);
	public void createPMDataTable();

}

package com.password.manager.ui;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Button;
import org.eclipse.wb.swt.SWTResourceManager;
import com.password.manager.bean.QueryData;
import com.password.manager.dao.impl.DBActionsImpl;
import com.password.manager.util.Constants;
import com.password.manager.util.Utilities;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class DetailsPage extends Dialog {

	protected Object    result;
	protected Shell     shlDetailsPage;
	private   Text      txtHead,txtUsername,txtPassword,txtReNewPassowrd;
	private   Combo     cmbLbl,cmbExHeads;
	private   Text      txtConsole;
	private   Table     tableDetails;
	private   Button    btnChkEdit,btnChkAddNew,btnChkUpdate,btnChkDelete,btnFetch,btnUpdate,btnInsert,btnDelete,btnClose;
	private   Label     lblUsername,lblPassword,lblReTypePassword,lblLabel,lblExistingHeads,lblAccName,lblHeader,lblPasswordVault;
	private   Composite cmpLeft,cmpMain,cmpTitle,cmpDetails,cmpTable,cmpButtons,cmpConsole;
	private   GridData  gd_cmpLeft,gd_cmpMain,gd_cmpTitle,gd_cmpDetails,gd_cmbLbl,gd_cmbExHeads,gd_txtHead,
	                    gd_txtUsername,gd_txtPassword,gd_txtReNewPassowrd,gd_cmpTable,gd_tableDetails,
	                    gd_cmpButtons,gd_btnClose,gd_cmpConsole,gd_txtConsole;
	private  TableItem tableItem;

	
	public DetailsPage(Shell parent, int style) {
		super(parent, style);		
	}
	public Object open() {
		createContents();
		shlDetailsPage.open();
		shlDetailsPage.layout();
		Display display = getParent().getDisplay();
		Monitor primary = display.getPrimaryMonitor();
		Rectangle bounds = primary.getBounds();
		Rectangle rect = shlDetailsPage.getBounds();
		int x = bounds.x + (bounds.width - rect.width) / 2;
		int y = bounds.y + (bounds.height - rect.height) / 2;
		shlDetailsPage.setLocation(x, y);			
		while (!shlDetailsPage.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}
	private void createContents() {
		
		DBActionsImpl dbActions_1 = new DBActionsImpl();
		Utilities util_1 = new Utilities();
//shlDetailsPage				
		shlDetailsPage = new Shell(getParent(), SWT.CLOSE | SWT.MIN | SWT.TITLE | SWT.PRIMARY_MODAL);
		shlDetailsPage.setImage(null);
		shlDetailsPage.setBackground(SWTResourceManager.getColor(245, 255, 250));
		shlDetailsPage.setSize(836, 590);
		shlDetailsPage.setText("password VAULT");
		shlDetailsPage.setLayout(new GridLayout(2, false));
//cmpLeft						
		cmpLeft = new Composite(shlDetailsPage, SWT.BORDER);
		gd_cmpLeft = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_cmpLeft.heightHint = 539 ;
		gd_cmpLeft.widthHint = 126;
		cmpLeft.setLayoutData(gd_cmpLeft);
		cmpLeft.setEnabled(false);
		cmpLeft.setBackground(SWTResourceManager.getColor(255, 165, 0));
		cmpLeft.setLayout(null);		
//cmpMain				
		cmpMain = new Composite(shlDetailsPage, SWT.NONE);
		cmpMain.setBackground(SWTResourceManager.getColor(245, 255, 250));
		cmpMain.setLayout(new GridLayout(1, false));
		gd_cmpMain = new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1);
		gd_cmpMain.widthHint = 685;
		gd_cmpMain.heightHint = 289;
		cmpMain.setLayoutData(gd_cmpMain);
//cmpTitle		
		cmpTitle = new Composite(cmpMain, SWT.NONE);
		cmpTitle.setBackground(SWTResourceManager.getColor(245, 255, 250));
		gd_cmpTitle = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_cmpTitle.widthHint = 677;
		gd_cmpTitle.heightHint = 46;
		cmpTitle.setLayoutData(gd_cmpTitle);
//lblPasswordVault		
		lblPasswordVault = new Label(cmpTitle, SWT.NONE);
		lblPasswordVault.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_RED));
		lblPasswordVault.setBackground(SWTResourceManager.getColor(245, 255, 250));
		lblPasswordVault.setFont(SWTResourceManager.getFont("Bradley Hand ITC", 14, SWT.BOLD | SWT.ITALIC));
		lblPasswordVault.setBounds(497, 10, 180, 36);
		lblPasswordVault.setText("password VAULT");
//lblHeader		
		lblHeader = new Label(cmpTitle, SWT.SEPARATOR | SWT.HORIZONTAL);
		lblHeader.setBackground(SWTResourceManager.getColor(SWT.COLOR_DARK_GREEN));
		lblHeader.setBounds(0, 29, 491, 9);
//cmpDetails		
		cmpDetails = new Composite(cmpMain, SWT.NONE);
		cmpDetails.setBackground(SWTResourceManager.getColor(245, 255, 250));
		cmpDetails.setLayout(new GridLayout(4, false));
		gd_cmpDetails = new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1);
		gd_cmpDetails.heightHint = 177;
		cmpDetails.setLayoutData(gd_cmpDetails);
//lblLabel		
		lblLabel = new Label(cmpDetails, SWT.NONE);
		lblLabel.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblLabel.setBackground(SWTResourceManager.getColor(245, 255, 250));
		lblLabel.setText("Label");
//cmbLbl		
		cmbLbl = new Combo(cmpDetails, SWT.NONE);
		cmbLbl.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		cmbLbl.setForeground(SWTResourceManager.getColor(SWT.COLOR_LIST_FOREGROUND));
		cmbLbl.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		gd_cmbLbl = new GridData(SWT.LEFT, SWT.FILL, false, false, 1, 1);
		gd_cmbLbl.widthHint = 160;
		cmbLbl.setLayoutData(gd_cmbLbl);
		String [] Items1 = {"","BANKS","ENTERTAINMENT","OFFICE"};
		cmbLbl.setItems(Items1);
//lblExistingHeads		
		lblExistingHeads = new Label(cmpDetails, SWT.NONE);
		lblExistingHeads.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblExistingHeads.setBackground(SWTResourceManager.getColor(245, 255, 250));
		lblExistingHeads.setText("Existing Account's");
//cmbExHeads		
		cmbExHeads = new Combo(cmpDetails, SWT.NONE);
		cmbExHeads.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		cmbExHeads.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		gd_cmbExHeads = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_cmbExHeads.widthHint = 160;
		cmbExHeads.setLayoutData(gd_cmbExHeads);
//Logic to populate the existing heads from the DB.		
		if(!util_1.istableExists(Constants.DB_PM_TABLE)){
			dbActions_1.createPMDataTable();						
		} 
		QueryData queryData =  dbActions_1.getExistingHeads();	
		if(queryData.getHead()!=null){
			cmbExHeads.setItems(queryData.getHead());
		}
//lblAccName		
		lblAccName = new Label(cmpDetails, SWT.NONE);
		lblAccName.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblAccName.setBackground(SWTResourceManager.getColor(245, 255, 250));
		lblAccName.setText("Account Name");
//txtHead		
		txtHead = new Text(cmpDetails, SWT.BORDER);
		txtHead.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		txtHead.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		gd_txtHead = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_txtHead.widthHint = 179;
		txtHead.setLayoutData(gd_txtHead);
		txtHead.setTextLimit(30);
//btnChkEdit		
		btnChkEdit = new Button(cmpDetails, SWT.CHECK);
		btnChkEdit.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		btnChkEdit.setText("Edit");
		btnChkEdit.setBackground(SWTResourceManager.getColor(245, 255, 250));
//btnChkAddNew				
		btnChkAddNew = new Button(cmpDetails, SWT.CHECK);
		btnChkAddNew.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		btnChkAddNew.setText("Add New");
		btnChkAddNew.setBackground(SWTResourceManager.getColor(245, 255, 250));
//lblUsername		
		lblUsername = new Label(cmpDetails, SWT.NONE);
		lblUsername.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblUsername.setBackground(SWTResourceManager.getColor(245, 255, 250));
		lblUsername.setText("User name");
//txtUsername		
		txtUsername = new Text(cmpDetails, SWT.BORDER);
		txtUsername.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		txtUsername.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		gd_txtUsername = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_txtUsername.widthHint = 179;
		txtUsername.setLayoutData(gd_txtUsername);
		txtUsername.setTextLimit(50);
//btnChkUpdate		
		btnChkUpdate = new Button(cmpDetails, SWT.CHECK);
		btnChkUpdate.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		btnChkUpdate.setText("Update");
		btnChkUpdate.setBackground(SWTResourceManager.getColor(245, 255, 250));
//btnChkDelete		
		btnChkDelete = new Button(cmpDetails, SWT.CHECK);
		btnChkDelete.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		btnChkDelete.setText("Delete");
		btnChkDelete.setBackground(SWTResourceManager.getColor(245, 255, 250));
//lblPassword		
		lblPassword = new Label(cmpDetails, SWT.NONE);
		lblPassword.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblPassword.setBackground(SWTResourceManager.getColor(245, 255, 250));
		lblPassword.setText("Password");
//txtPassword		
		txtPassword = new Text(cmpDetails, SWT.BORDER | SWT.PASSWORD);
		txtPassword.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		txtPassword.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		gd_txtPassword = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_txtPassword.widthHint = 179;
		txtPassword.setLayoutData(gd_txtPassword);
		txtPassword.setTextLimit(40);
		new Label(cmpDetails, SWT.NONE);
		new Label(cmpDetails, SWT.NONE);
//lblReTypePassword		
		lblReTypePassword = new Label(cmpDetails, SWT.NONE);
		lblReTypePassword.setBackground(SWTResourceManager.getColor(245, 255, 250));
		lblReTypePassword.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblReTypePassword.setText("Re Password");
//txtReNewPassowrd		
		txtReNewPassowrd = new Text(cmpDetails, SWT.BORDER | SWT.PASSWORD);
		txtReNewPassowrd.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		txtReNewPassowrd.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		gd_txtReNewPassowrd = new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1);
		gd_txtReNewPassowrd.widthHint = 180;
		txtReNewPassowrd.setLayoutData(gd_txtReNewPassowrd);
		new Label(cmpDetails, SWT.NONE);
		new Label(cmpDetails, SWT.NONE);
//cmpTable		
		cmpTable = new Composite(cmpMain, SWT.NONE);
		cmpTable.setBackground(SWTResourceManager.getColor(245, 255, 250));
		cmpTable.setLayout(new GridLayout(1, false));
		gd_cmpTable = new GridData(SWT.LEFT, SWT.FILL, false, false, 1, 1);
		gd_cmpTable.widthHint = 507;
		gd_cmpTable.heightHint = 165;
		cmpTable.setLayoutData(gd_cmpTable);
//Table tableDetails		
		tableDetails = new Table(cmpTable, SWT.BORDER | SWT.FULL_SELECTION );
		tableDetails.setLinesVisible(true);
		tableDetails.setHeaderVisible(true);
		tableDetails.setBackground(SWTResourceManager.getColor(245, 255, 250));
		tableDetails.setTouchEnabled(true);
		gd_tableDetails = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		gd_tableDetails.widthHint = 515;
		tableDetails.setLayoutData(gd_tableDetails);
//TableColumn column						
		for (int inx = 0; inx < 5; inx++){	
			TableColumn column = new TableColumn(tableDetails, SWT.NONE);
			if (inx == 0 ){
				column.setText("Edit");
				column.setWidth(30);
			}			
			else if (inx == 1 ){
				column.setText("S.No");
				column.setWidth(45);
			}
			else if (inx == 2){
				column.setText("Account");
				column.setWidth(145);
			}
			else if (inx == 3){
				column.setText("User name");
				column.setWidth(145);
			}
			else if (inx == 4){
				column.setText("Password");
				column.setWidth(145);
			}			
		}
//Table Item tableItem 		
		tableItem = new TableItem(tableDetails, SWT.NONE);
//TableEditor editor
		 final TableEditor editor = new TableEditor(tableDetails);
		 editor.horizontalAlignment = SWT.LEFT;
		 editor.grabHorizontal = true;
		 editor.minimumWidth = 50;
		 final int EDITABLECOLUMN = 4;
		 tableDetails.addSelectionListener(new SelectionListener() {			
			@Override
			public void widgetSelected(SelectionEvent e) {
				 Control oldEditor = editor.getEditor();
				 if (oldEditor != null)oldEditor.dispose();
				 tableItem = (TableItem)e.item;  
				 if (tableItem == null) return;
				 Text newEditor = new Text(tableDetails, SWT.NONE);
				 newEditor.setText(tableItem.getText(EDITABLECOLUMN));
				 newEditor.addModifyListener(new ModifyListener() {
			          public void modifyText(ModifyEvent me) {
			            Text text = (Text) editor.getEditor();
			            editor.getItem().setText(EDITABLECOLUMN, text.getText());
			          }
			        });
				    newEditor.selectAll();
			        newEditor.setFocus();
			        editor.setEditor(newEditor, tableItem, EDITABLECOLUMN);
			}			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
			}
		});						
//cmpButtons		
		cmpButtons = new Composite(cmpMain, SWT.NONE);
		cmpButtons.setBackground(SWTResourceManager.getColor(245, 255, 250));
		cmpButtons.setLayout(new GridLayout(5, false));
		gd_cmpButtons = new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1);
		gd_cmpButtons.heightHint = 42;
		cmpButtons.setLayoutData(gd_cmpButtons);
//Button Fetch		
		btnFetch = new Button(cmpButtons, SWT.NONE);
		btnFetch.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		btnFetch.setText("Fetch");
		btnFetch.addSelectionListener(new SelectionListener() {			
			@Override
			public void widgetSelected(SelectionEvent arg0) {					
				QueryData qData = new QueryData();
				
				if((cmbExHeads.getText()!=null)&&(cmbExHeads.getText()!="")){
					qData.setWhereClauseField(cmbExHeads.getText());					
				}
				else if((cmbLbl.getText()!=null) || (cmbLbl.getText()!="")){
					qData.setWhereClauseField(cmbLbl.getText());
				}
				else{
					clearWidgets();							
					MessageBox mBox = new MessageBox(shlDetailsPage);
					mBox.setMessage(Constants.NULL_WHERE_CLAUSE);
					mBox.open();
					return;
				}
				DBActionsImpl dbActions = new DBActionsImpl();				
				QueryData querydata = dbActions.selectPMDetails(qData);								
				int cnt = querydata.getRowCnt(); // Time being i printed the row cnt under S.No..but when count is more than 1 then i should be interating it and addiding one by one to the table.
				tableItem.setText(new String [] {"",Integer.toString(cnt),querydata.getAccountDB(), querydata.getUserNameDB(),querydata.getPassWordDB()});					
			}			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {							
			}
		});	
// Insert Button
		btnInsert = new Button(cmpButtons, SWT.NONE);
		btnInsert.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		btnInsert.setText("Insert");
		btnInsert.addSelectionListener(new SelectionListener() {			
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				DBActionsImpl dbActions = new DBActionsImpl();
				Utilities util = new Utilities();
				QueryData qdata = new QueryData();
				qdata = setNewHeadDetails( qdata);
				if (isRetypePasswordMatched())
				{
					if(!util.istableExists(Constants.DB_PM_TABLE)){
						dbActions.createPMDataTable();
					} 
					else if (isDataNotNull()){
						dbActions.insertPMDetails(qdata);
						txtConsole.setText("The Data updated successfully!!");
						QueryData queryData =  dbActions.getExistingHeads();
						if(queryData.getHead()!=null){
							cmbExHeads.setItems(queryData.getHead());
						}						
					}
					else {
						MessageBox mBox = new MessageBox(shlDetailsPage);
						mBox.setMessage(Constants.EMPTY_FIELDS);
						mBox.open();					
					}
				}
				else{
					MessageBox mBox = new MessageBox(shlDetailsPage);
					mBox.setMessage(Constants.PASSWORD_MATCH);
					mBox.open();
				}
				clearWidgets();				
			}			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {}
			});	
//Button Update	
		btnUpdate = new Button(cmpButtons, SWT.NONE);
		btnUpdate.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		btnUpdate.setText("Update");
// Delete Button		
		btnDelete = new Button(cmpButtons, SWT.NONE);
		btnDelete.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		btnDelete.setText("Delete");
		btnDelete.addSelectionListener(new SelectionListener() {			
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if((cmbExHeads.getText()!=null)&&(cmbExHeads.getText()!="")){
					DBActionsImpl dbActions = new DBActionsImpl();
					QueryData qData = new QueryData();
					qData = setNewHeadDetails( qData);
					dbActions.deletePMDetails(qData);
					txtConsole.setText("The Data Deleted successfully!!");
					qData =  dbActions.getExistingHeads();
	// This if loop logic is written to refresh the existing heads drop down after delete any Head				
					if(qData.getHead()!=null){
						cmbExHeads.setItems(qData.getHead());					
					}
					else{
						cmbExHeads.setItem(0,"");}
					clearWidgets();	
					tableDetails.clearAll();
				}
				else{
					MessageBox mBox = new MessageBox(shlDetailsPage);
					mBox.setMessage(Constants.NO_HEAD_SELECTED);
					mBox.open();
					return;
				}					
			}			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {								
			}
		});
//Button Close	
		btnClose = new Button(cmpButtons, SWT.NONE);
		btnClose.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		gd_btnClose = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_btnClose.widthHint = 63;
		btnClose.setLayoutData(gd_btnClose);
		btnClose.setText("Close");
		btnClose.addSelectionListener(new SelectionListener() {			
			@Override
			public void widgetSelected(SelectionEvent arg0) {				
				Utilities util_2 = new Utilities();
				MessageBox mBox = new MessageBox(shlDetailsPage);
				mBox.setMessage(Constants.CLOSE_WARNING);
				mBox.open();
				String folder = System.getenv("TEMP");
				util_2.clearFiles(folder);
				shlDetailsPage.close();				
			}			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub				
			}
		});

		cmpConsole = new Composite(cmpMain, SWT.NONE);
		cmpConsole.setBackground(SWTResourceManager.getColor(245, 255, 250));
		cmpConsole.setLayout(new FillLayout(SWT.HORIZONTAL));
		gd_cmpConsole = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_cmpConsole.widthHint = 676;
		cmpConsole.setLayoutData(gd_cmpConsole);
		
		txtConsole = new Text(cmpMain, SWT.BORDER);
		txtConsole.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.BOLD | SWT.ITALIC));
		txtConsole.setEnabled(false);
		txtConsole.setEditable(false);
		txtConsole.setBackground(SWTResourceManager.getColor(245, 255, 250));
		gd_txtConsole = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		gd_txtConsole.heightHint = 73;
		txtConsole.setLayoutData(gd_txtConsole);
		
	}		
	
	private QueryData setNewHeadDetails(QueryData qData){
		qData.setPmHead(txtHead.getText());
		qData.setLabel(cmbLbl.getText());
		qData.setPmUsername(txtUsername.getText());
		qData.setPmPassword(txtPassword.getText());
		qData.setPmReNewPassword(txtReNewPassowrd.getText());
		qData.setPmExistingHead(cmbExHeads.getText());
		return qData;		
	}
	
	private void clearWidgets(){
		txtHead.setText("");
		cmbLbl.setText("");
		txtUsername.setText("");
		txtPassword.setText("");
		txtReNewPassowrd.setText("");
		cmbExHeads.setText("");
	}
	
	private boolean isDataNotNull(){
		boolean isNotNull = false;		
		if((txtHead.getText()!=null) && ((txtHead.getText()!=""))
			&& (cmbLbl.getText()!=null) && (cmbLbl.getText()!="")
			&& (txtUsername.getText()!=null) && (txtUsername.getText()!="") 
			&& (txtPassword.getText()!=null) && (txtPassword.getText()!="")
			&& (txtReNewPassowrd.getText()!=null) && (txtReNewPassowrd.getText()!="")) {
			isNotNull = true;			
		}					
		return isNotNull;
	}
	
	private boolean isRetypePasswordMatched(){
		boolean isPasswordMatched = false;		
		if (txtPassword.getText().equals(txtReNewPassowrd.getText())){
			isPasswordMatched = true;
		}		
		return isPasswordMatched;
	}
	
	
}

package com.password.manager.ui;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;
import com.password.manager.bean.PMData;
import com.password.manager.util.Constants;
import com.password.manager.util.Utilities;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.GridData;


public class LoginPage extends Dialog {

	protected Object result;
	protected Shell shlPasswordManager;
	private Text txtUsername;
	private Text txtPassword;

	public LoginPage(Shell parent, int style) {
		super(parent, style);		
	}

	public Object open() {
		createContents();
		shlPasswordManager.open();
		shlPasswordManager.layout();
		Display display = getParent().getDisplay();
       
		/*Setting the dialog to center of the screen*/	
		
		Monitor primary = display.getPrimaryMonitor();
		Rectangle bounds = primary.getBounds();
		Rectangle rect = shlPasswordManager.getBounds();
		int x = bounds.x + (bounds.width - rect.width) / 2;
		int y = bounds.y + (bounds.height - rect.height) / 2;		
		shlPasswordManager.setLocation(x, y);						
		while (!shlPasswordManager.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}
	private void createContents()
	{
		shlPasswordManager = new Shell(getParent(), SWT.BORDER | SWT.CLOSE | SWT.MIN);
		shlPasswordManager.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		shlPasswordManager.setMinimized(true);		
		shlPasswordManager.setSize(275, 236);
		shlPasswordManager.setText("Password Manager");	
		shlPasswordManager.setLayout(new GridLayout(1, false));
				
		Composite cmpPM = new Composite(shlPasswordManager, SWT.NONE);
		cmpPM.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		GridLayout gl_cmpPM = new GridLayout(3,  false);
		gl_cmpPM.horizontalSpacing = 3;
		cmpPM.setLayout(gl_cmpPM);
		GridData gd_cmpPM = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_cmpPM.widthHint = 260;
		cmpPM.setLayoutData(gd_cmpPM);
			
		Label lblTitle = new Label(cmpPM, SWT.CENTER);
		lblTitle.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		lblTitle.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 3, 1));
		lblTitle.setAlignment(SWT.CENTER);
		lblTitle.setText("Password Vault");
		
		Composite cmpNamePwd = new Composite(shlPasswordManager, SWT.NONE);
		cmpNamePwd.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		cmpNamePwd.setLayout(new GridLayout(2, false));
		GridData gd_cmpNamePwd = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_cmpNamePwd.widthHint = 260;
		gd_cmpNamePwd.heightHint = 71;
		cmpNamePwd.setLayoutData(gd_cmpNamePwd);
		
		Label lblUsername = new Label(cmpNamePwd, SWT.NONE);
		lblUsername.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		lblUsername.setAlignment(SWT.CENTER);
		lblUsername.setText("User name");
		
		txtUsername = new Text(cmpNamePwd, SWT.BORDER);
		txtUsername.setBackground(SWTResourceManager.getColor(SWT.COLOR_INFO_BACKGROUND));
		GridData gd_txtUsername = new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1);
		gd_txtUsername.widthHint = 125;
		txtUsername.setLayoutData(gd_txtUsername);
				
		Label lblPassword = new Label(cmpNamePwd, SWT.NONE);
		lblPassword.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		lblPassword.setText("Password");
		
		txtPassword = new Text(cmpNamePwd,SWT.PASSWORD | SWT.BORDER);
		txtPassword.setBackground(SWTResourceManager.getColor(SWT.COLOR_INFO_BACKGROUND));
		GridData gd_txtPassword = new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1);
		gd_txtPassword.widthHint = 125;
		txtPassword.setLayoutData(gd_txtPassword);
					
		Composite cnpNewUser = new Composite(shlPasswordManager, SWT.NONE);
		cnpNewUser.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		cnpNewUser.setLayout(new GridLayout(3, true));
		GridData gd_cnpNewUser = new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1);
		gd_cnpNewUser.widthHint = 260;
		cnpNewUser.setLayoutData(gd_cnpNewUser);
		new Label(cnpNewUser, SWT.NONE);
		
		Label lblNewUserRegister = new Label(cnpNewUser, SWT.NONE);
		lblNewUserRegister.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		lblNewUserRegister.setAlignment(SWT.CENTER);
		lblNewUserRegister.setText("New User ? ");
		
		Link lnkSignup = new Link(cnpNewUser, SWT.NONE);
		lnkSignup.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		lnkSignup.setText("<a>Sign Up</a>");
		lnkSignup.addSelectionListener(new SelectionListener() {		
			@Override
			public void widgetSelected(SelectionEvent arg0) {				
				Shell shell = new Shell();
				NewUserCreation newuser = new NewUserCreation(shell, 0);
				shlPasswordManager.close();
				newuser.open();				
			}			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub				
			}
		});		
		Composite cmpButtons = new Composite(shlPasswordManager, SWT.NONE);
		cmpButtons.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		cmpButtons.setLayout(new GridLayout(3, true));
		GridData gd_cmpButtons = new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 2);
		gd_cmpButtons.widthHint = 260;
		gd_cmpButtons.heightHint = 45;
		cmpButtons.setLayoutData(gd_cmpButtons);
		new Label(cmpButtons, SWT.NONE);
		
		Button btnLogin = new Button(cmpButtons, SWT.NONE);
		btnLogin.setText("Login   ");
		shlPasswordManager.setDefaultButton(btnLogin);
		btnLogin.addSelectionListener(new SelectionListener() {			
			@Override
			public void widgetSelected(SelectionEvent arg0) {								
			    Shell shell = new Shell();
				PMData pmdata = new PMData();				
				//MainPage mPage = new MainPage(shell, 0);				
				DetailsPage mPage = new DetailsPage(shell, 0);
								
				pmdata.setPassword(txtPassword.getText());				
				pmdata.setUsername(txtUsername.getText());
											
				Utilities util = new Utilities();
				String folder = System.getenv("TEMP");
				if(util.istableExists(Constants.DB_USER_TABLE)){
					if (util.isUserValid(pmdata)) {						
						shlPasswordManager.close();	
						System.out.println("Inside login page : util.clearFiles(folder);");
						util.clearFiles(folder);
						if(shell!=null){
							mPage.open();								
						}						
					}	
					else {
						txtPassword.setText("");
						txtUsername.setText("");
						MessageBox mBox = new MessageBox(shlPasswordManager, 0);
						mBox.setMessage(Constants.INCORRECT_CREDNTIALS);
						mBox.open();						
					}					
				}
				else{
					txtPassword.setText("");
					txtUsername.setText("");
					MessageBox mBox = new MessageBox(shlPasswordManager, 0);
					mBox.setMessage(Constants.NO_DATA_ERROR);
					mBox.open();
				}																									
			}			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub				
			}
		});			
		Button btnCancel = new Button(cmpButtons, SWT.NONE);
		btnCancel.setText("Cancel");
		btnCancel.addSelectionListener(new SelectionListener() {			
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
				shlPasswordManager.close();
			}			
			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub		
			}
		});
	}
}
